import os
import streamlit as st
import tempfile
import fitz  # PyMuPDF
import docx
import language_tool_python
import re
from collections import Counter
import pandas as pd
import plotly.express as px
import heapq
from typing import List, Dict, Tuple, Optional

# --- Career Path Recommender (A* Implementation) ---
class CareerNode:
    def __init__(self, role: str, skills: Dict[str, int], years_experience: int):
        """
        Represents a node in the career graph.
        
        Args:
            role: Current job role (e.g., "Junior Developer")
            skills: Dictionary of skill names to proficiency levels (1-5)
            years_experience: Total years of experience
        """
        self.role = role
        self.skills = skills
        self.years_experience = years_experience
        
    def __lt__(self, other):
        # Required for heapq comparison
        return id(self) < id(other)

class CareerPathRecommender:
    def __init__(self):
        # Initialize with a predefined career graph
        self.career_graph = self._build_career_graph()
        
    def _build_career_graph(self) -> Dict[str, Dict[str, dict]]:
        """
        Builds a career graph with roles as nodes and requirements as edges.
        
        Returns:
            Adjacency list representation of the career graph
        """
        # This is a simplified example - you'd want to expand this with real-world data
        graph = {
            "Junior Developer": {
                "Mid Developer": {
                    "required_skills": {"Python": 3, "SQL": 2, "Git": 2},
                    "years_required": 2
                },
                "Data Analyst": {
                    "required_skills": {"Python": 2, "SQL": 3, "Excel": 3},
                    "years_required": 1.5
                }
            },
            "Mid Developer": {
                "Senior Developer": {
                    "required_skills": {"Python": 4, "System Design": 3, "Leadership": 2},
                    "years_required": 3
                },
                "Data Scientist": {
                    "required_skills": {"Python": 4, "Statistics": 3, "Machine Learning": 3},
                    "years_required": 2
                },
                "DevOps Engineer": {
                    "required_skills": {"AWS": 3, "Docker": 3, "CI/CD": 2},
                    "years_required": 2
                }
            },
            "Data Analyst": {
                "Data Scientist": {
                    "required_skills": {"Python": 3, "Statistics": 3, "Machine Learning": 2},
                    "years_required": 2
                },
                "Business Analyst": {
                    "required_skills": {"SQL": 3, "Tableau": 3, "Communication": 4},
                    "years_required": 1.5
                }
            },
            "Senior Developer": {
                "Tech Lead": {
                    "required_skills": {"Leadership": 4, "System Design": 4, "Project Management": 3},
                    "years_required": 3
                },
                "Engineering Manager": {
                    "required_skills": {"Leadership": 4, "People Management": 4, "Communication": 4},
                    "years_required": 2
                }
            },
            "Data Scientist": {
                "Senior Data Scientist": {
                    "required_skills": {"Machine Learning": 4, "Statistics": 4, "Big Data": 3},
                    "years_required": 3
                },
                "ML Engineer": {
                    "required_skills": {"Machine Learning": 4, "Software Engineering": 3, "MLOps": 3},
                    "years_required": 2
                }
            }
        }
        return graph
    
    def _parse_resume_for_current_state(self, resume_text: str) -> CareerNode:
        """
        Parses resume text to determine current career state.
        
        Args:
            resume_text: Extracted text from resume
            
        Returns:
            CareerNode representing current position
        """
        # Simplified parsing - in practice you'd want more sophisticated NLP
        roles = ["Junior Developer", "Mid Developer", "Senior Developer",
                 "Data Analyst", "Data Scientist", "Tech Lead"]
        
        # Default to Junior Developer if no role found
        current_role = "Junior Developer"
        for role in roles:
            if role.lower() in resume_text.lower():
                current_role = role
                break
                
        # Extract skills (simplified)
        skills = {}
        common_skills = ["Python", "SQL", "Git", "Java", "JavaScript", "HTML", "CSS",
                        "Machine Learning", "Statistics", "AWS", "Docker", "Tableau"]
        
        for skill in common_skills:
            if skill.lower() in resume_text.lower():
                # Assign random proficiency (1-3 for junior, 2-4 for mid, etc.)
                if "Junior" in current_role:
                    skills[skill] = 2
                elif "Mid" in current_role:
                    skills[skill] = 3
                else:
                    skills[skill] = 4
                    
        # Estimate years of experience (simplified)
        experience_years = 1
        if "Senior" in current_role:
            experience_years = 5
        elif "Mid" in current_role:
            experience_years = 3
            
        return CareerNode(current_role, skills, experience_years)
    
    def _calculate_skill_gap(self, current_skills: Dict[str, int], required_skills: Dict[str, int]) -> float:
        """
        Calculates the skill gap between current skills and required skills.
        
        Args:
            current_skills: Dictionary of current skill levels
            required_skills: Dictionary of required skill levels
            
        Returns:
            Normalized skill gap score (0-1, where 0 is no gap)
        """
        total_gap = 0
        max_possible_gap = 0
        
        for skill, level in required_skills.items():
            current_level = current_skills.get(skill, 0)
            gap = max(0, level - current_level)
            total_gap += gap
            max_possible_gap += level  # If current_level is 0
            
        if max_possible_gap == 0:
            return 0
            
        return total_gap / max_possible_gap
    
    def _heuristic(self, node: CareerNode, goal_role: str) -> float:
        """
        Heuristic function for A* - estimates cost to reach goal.
        
        Args:
            node: Current career node
            goal_role: Target role
            
        Returns:
            Estimated cost to reach goal
        """
        # Simple heuristic based on role hierarchy
        role_hierarchy = {
            "Junior Developer": 0,
            "Mid Developer": 1,
            "Data Analyst": 1,
            "Senior Developer": 2,
            "Data Scientist": 2,
            "DevOps Engineer": 2,
            "Tech Lead": 3,
            "Engineering Manager": 3,
            "Senior Data Scientist": 3,
            "ML Engineer": 3
        }
        
        current_level = role_hierarchy.get(node.role, 0)
        goal_level = role_hierarchy.get(goal_role, 3)
        
        return max(0, goal_level - current_level)
    
    def find_career_path(self, resume_text: str, goal_role: str) -> Tuple[List[Dict], List[Dict]]:
        """
        Finds optimal career path from current resume to goal role using A*-like search.
        
        Args:
            resume_text: Extracted text from resume
            goal_role: Target role to reach
            
        Returns:
            Tuple of (path, skill_gaps) where:
            - path is list of roles in the optimal path
            - skill_gaps is list of skill gaps between steps
        """
        # Parse current state from resume
        start_node = self._parse_resume_for_current_state(resume_text)
        
        # Priority queue: (f_score, count, node, path, skill_gaps)
        open_set = []
        heapq.heappush(open_set, (0, 0, start_node, [start_node.role], []))
        
        count = 1  # Used to break ties in heapq
        visited = set()
        
        while open_set:
            _, _, current, path, skill_gaps = heapq.heappop(open_set)
            
            if current.role == goal_role:
                return path, skill_gaps
                
            if current.role in visited:
                continue
                
            visited.add(current.role)
            
            # Get neighbors in career graph
            neighbors = self.career_graph.get(current.role, {})
            for neighbor_role, edge_data in neighbors.items():
                if neighbor_role in visited:
                    continue
                    
                # Calculate skill gap to this neighbor
                required_skills = edge_data["required_skills"]
                skill_gap = self._calculate_skill_gap(current.skills, required_skills)
                
                # Create neighbor node
                neighbor_skills = {**current.skills}
                for skill, level in required_skills.items():
                    if skill not in neighbor_skills or neighbor_skills[skill] < level:
                        neighbor_skills[skill] = level
                        
                neighbor_node = CareerNode(
                    neighbor_role,
                    neighbor_skills,
                    current.years_experience + edge_data["years_required"]
                )
                
                # Calculate g_score (cost from start) and f_score
                g_score = len(path) + skill_gap * 2  # Weight skill gap more
                h_score = self._heuristic(neighbor_node, goal_role)
                f_score = g_score + h_score
                
                # Add to open set
                heapq.heappush(
                    open_set,
                    (
                        f_score,
                        count,
                        neighbor_node,
                        path + [neighbor_role],
                        skill_gaps + [{
                            "from": current.role,
                            "to": neighbor_role,
                            "skills_needed": [
                                f"{skill} (current: {current.skills.get(skill, 0)} → needed: {level})"
                                for skill, level in required_skills.items()
                                if current.skills.get(skill, 0) < level
                            ],
                            "years_required": edge_data["years_required"]
                        }]
                    )
                )
                count += 1
                
        # If goal not found, return path to closest node
        return path, skill_gaps

# --- Utility Functions ---
def extract_text_from_pdf(file_path):
    text = ""
    with fitz.open(file_path) as pdf:
        for page in pdf:
            text += page.get_text()
    return text

def extract_text_from_docx(file_path):
    doc = docx.Document(file_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

def detect_file_type(file):
    if file.name.endswith('.pdf'):
        return 'pdf'
    elif file.name.endswith('.docx'):
        return 'docx'
    else:
        return 'unsupported'

# --- Feedback Generator ---
tool = language_tool_python.LanguageTool('en-US', config={'cacheSize': 0})

def get_resume_feedback(text):
    matches = tool.check(text)
    seen = set()
    grammar_issues = []
    for match in matches:
        issue = match.message.strip()
        if issue not in seen and not issue.lower().startswith("possible spelling mistake"):
            seen.add(issue)
            grammar_issues.append({
                "issue": issue,
                "example": text[match.offset:match.offset + match.errorLength],
                "color": f"hsl({len(grammar_issues)*60}, 70%, 80%)"  # Different color for each issue
            })
        if len(grammar_issues) == 5:
            break

    if not grammar_issues:
        grammar_section = "✅ No major grammar issues detected."
        grammar_score = 100
    else:
        grammar_section = grammar_issues
        grammar_score = max(60, 100 - len(grammar_issues) * 8)

    sections = ["summary", "skills", "projects", "experience", "education", "certifications"]
    missing_sections = []
    text_lower = text.lower()
    for section in sections:
        if section not in text_lower:
            missing_sections.append(section.capitalize())

    if not missing_sections:
        section_text = "✅ All major resume sections are present."
        section_score = 100
    else:
        section_text = f"⚠️ **Missing Sections:** {', '.join(missing_sections)}"
        section_score = max(60, 100 - len(missing_sections) * 5)

    words = re.findall(r'\b\w+\b', text.lower())
    common = Counter(words).most_common(10)
    keywords = [word for word, count in common if word.isalpha()]
    keyword_text = "💡 **Most Frequent Keywords:** " + ", ".join(keywords[:10])

    overall_score = int((grammar_score + section_score) / 2)

    return grammar_section, section_text, keyword_text, overall_score, grammar_score, section_score, missing_sections

# --- Smart Suggestions ---
def generate_smart_suggestions(score, missing_sections, keywords):
    suggestions = []
    
    if score >= 90:
        suggestions.append("🎯 Your resume is excellent! Consider adding quantifiable achievements.")
    elif score >= 70:
        suggestions.append("🎯 Good foundation. Focus on adding missing sections and quantifying results.")
    else:
        suggestions.append("🎯 Start by fixing grammar issues and adding missing sections.")
    
    if 'Projects' in missing_sections:
        suggestions.append("🛠️ Add a Projects section to showcase your work.")
    if 'Certifications' in missing_sections:
        suggestions.append("📜 Include relevant certifications with issuing organizations.")
    
    if len(keywords) > 0 and keywords[0] in ['i', 'my', 'me']:
        suggestions.append("📝 Reduce first-person pronouns for more professional tone.")
    
    suggestions.extend([
        "⏳ Use standard section headings (e.g., 'Work Experience')",
        "🔍 Quantify achievements with numbers where possible",
        "✨ Start bullet points with strong action verbs",
        "📏 Keep to 1 page unless you have 10+ years experience"
    ])
    
    return suggestions[:5]

# --- Streamlit UI ---
def main():
    # Custom CSS for professional UI
    st.set_page_config(
        page_title="Resume Critic Pro", 
        layout="centered",
        page_icon="📄"
    )
    
    st.markdown("""
        <style>
            .main {
                max-width: 800px;
                margin: 0 auto;
                padding: 2rem;
            }
            
            .stApp {
                background-color: #f8f9fa;
                display: flex;
                justify-content: center;
            }
            
            .stButton>button {
                background-color: #4b6cb7;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 10px 24px;
                font-weight: 500;
                width: 100%;
            }
            
            .stButton>button:hover {
                background-color: #3a56a0;
            }
            
            .stFileUploader>div>div>div>div {
                color: #4b6cb7;
                border-color: #4b6cb7;
            }
            
            .feedback-card {
                background: white;
                border-radius: 8px;
                padding: 1.5rem;
                margin: 1rem 0;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                border-left: 4px solid #4b6cb7;
            }
            
            .score-card {
                background: white;
                border-radius: 8px;
                padding: 1.5rem;
                margin: 1.5rem 0;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                text-align: center;
                border-top: 4px solid #4b6cb7;
            }
            
            .suggestion-card {
                background: #f0f5ff;
                border-radius: 6px;
                padding: 1rem;
                margin: 0.75rem 0;
                font-size: 14px;
                border-left: 3px solid #4b6cb7;
            }
            
            h1, h2, h3 {
                color: #2c3e50;
                text-align: center;
            }
            
            .graph-card {
                background: white;
                border-radius: 8px;
                padding: 1rem;
                margin: 1rem 0;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            
            .header-icon {
                display: block;
                margin: 0 auto;
                text-align: center;
                font-size: 3rem;
                color: #4b6cb7;
                margin-bottom: 1rem;
            }
            
            .grammar-item {
                padding: 0.75rem;
                margin: 0.5rem 0;
                border-radius: 6px;
                border-left: 4px solid;
            }
            
            .path-node {
                background: #e3f2fd;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto;
                font-weight: bold;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            
            .path-connector {
                height: 2px;
                background: #4b6cb7;
                margin: 0 auto;
                width: 60%;
                position: relative;
                top: 20px;
            }
            
            .path-container {
                display: flex;
                flex-direction: column;
                margin: 1rem 0;
            }
            
            .path-role {
                text-align: center;
                margin-top: 10px;
                font-weight: 500;
            }
            
            .skill-gap-card {
                background: #fff8e1;
                border-radius: 6px;
                padding: 1rem;
                margin: 0.5rem 0;
                font-size: 14px;
            }
            
            .path-visualization {
                display: flex;
                justify-content: center;
                align-items: center;
                margin: 2rem 0;
            }
            
            .path-step {
                display: flex;
                flex-direction: column;
                align-items: center;
                margin: 0 1rem;
            }
            
            .path-arrow {
                font-size: 24px;
                color: #4b6cb7;
                margin: 0 0.5rem;
            }
        </style>
    """, unsafe_allow_html=True)
    
    # Header with document icon
    st.markdown('<div class="header-icon">📄</div>', unsafe_allow_html=True)
    st.title("Resume Critic Pro")
    st.markdown("""
        <div style="text-align: center; color: #4b6cb7; margin-bottom: 2rem;">
            AI-powered resume analysis and feedback
        </div>
    """, unsafe_allow_html=True)
    
    # File Upload
    uploaded_file = st.file_uploader("Choose a resume file (PDF or DOCX)", type=["pdf", "docx"])
    
    if uploaded_file:
        file_type = detect_file_type(uploaded_file)
        
        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            tmp_file.write(uploaded_file.read())
            tmp_path = tmp_file.name
        
        if file_type == 'pdf':
            resume_text = extract_text_from_pdf(tmp_path)
        elif file_type == 'docx':
            resume_text = extract_text_from_docx(tmp_path)
        else:
            st.error("Unsupported file format. Please upload a PDF or DOCX file.")
            st.stop()
        
        if resume_text.strip():
            if st.button("Analyze Resume", type="primary", key="analyze_resume"):
                with st.spinner("Analyzing your resume..."):
                    # Store analysis results in session state
                    st.session_state.grammar_section, st.session_state.section_text, st.session_state.keyword_text, \
                    st.session_state.overall_score, st.session_state.grammar_score, st.session_state.section_score, \
                    st.session_state.missing_sections = get_resume_feedback(resume_text)
                    
                    # Store resume text for career path analysis
                    st.session_state.resume_text = resume_text
            
            # Display analysis results if they exist in session state
            if 'grammar_section' in st.session_state:
                # Display Results
                st.markdown("---")
                st.markdown("## Analysis Results")
                
                # Score Card
                st.markdown(f"""
                    <div class="score-card">
                        <h2>Your Resume Score</h2>
                        <div style="font-size: 42px; font-weight: bold; color: {'#4CAF50' if st.session_state.overall_score >= 85 else '#FF9800' if st.session_state.overall_score >= 70 else '#F44336'}; margin: 10px 0;">
                            {st.session_state.overall_score}/100
                        </div>
                        <div style="font-size: 16px; color: #4b5563;">
                            {"Excellent! Ready for applications" if st.session_state.overall_score >= 85 
                            else "Good, but could use improvements" if st.session_state.overall_score >= 70 
                            else "Needs work - see suggestions below"}
                        </div>
                    </div>
                """, unsafe_allow_html=True)
                
                # Pie Chart Visualization
                st.markdown("""
                    <div class="graph-card">
                        <h3 style="text-align: center;">Score Breakdown</h3>
                """, unsafe_allow_html=True)
                
                # Create dataframe for pie chart
                score_data = pd.DataFrame({
                    'Category': ['Grammar', 'Sections'],
                    'Score': [st.session_state.grammar_score, st.session_state.section_score],
                    'Color': ['#4b6cb7', '#6a4c93']
                })
                
                # Create pie chart
                fig = px.pie(score_data, 
                            values='Score', 
                            names='Category',
                            color='Color',
                            color_discrete_map={'Grammar':'#4b6cb7', 'Sections':'#6a4c93'})
                
                fig.update_traces(textinfo='percent+label', 
                                pull=[0.1, 0], 
                                marker=dict(line=dict(color='#ffffff', width=2)))
                fig.update_layout(showlegend=False)
                
                st.plotly_chart(fig, use_container_width=True)
                st.markdown("</div>", unsafe_allow_html=True)
                
                # Feedback Columns
                col1, col2 = st.columns(2)
                
                with col1:
                    # Grammar Feedback
                    st.markdown("""
                        <div class="feedback-card">
                            <h3>Grammar & Writing</h3>
                    """, unsafe_allow_html=True)
                    
                    if isinstance(st.session_state.grammar_section, str):
                        st.markdown(st.session_state.grammar_section)
                    else:
                        for i, issue in enumerate(st.session_state.grammar_section):
                            st.markdown(f"""
                                <div class="grammar-item" style="background-color: {issue['color']}; border-left-color: {issue['color'].replace('80%)', '50%)')}">
                                    <strong>• {issue['issue']}</strong><br>
                                    Example: "{issue['example']}"
                                </div>
                            """, unsafe_allow_html=True)
                    
                    st.markdown("</div>", unsafe_allow_html=True)
                    
                with col2:
                    # Section Feedback
                    st.markdown(f"""
                        <div class="feedback-card">
                            <h3>Structure & Sections</h3>
                            {st.session_state.section_text}
                        </div>
                    """, unsafe_allow_html=True)
                
                # Keywords
                st.markdown(f"""
                    <div class="feedback-card">
                        <h3>Keyword Analysis</h3>
                        {st.session_state.keyword_text}
                    </div>
                """, unsafe_allow_html=True)
                
                # Smart Suggestions (automatically shown)
                st.markdown("---")
                st.markdown("## Improvement Suggestions")
                
                suggestions = generate_smart_suggestions(
                    st.session_state.overall_score, 
                    st.session_state.missing_sections, 
                    re.findall(r'\b\w+\b', st.session_state.resume_text.lower())
                )
                
                for suggestion in suggestions:
                    st.markdown(f"""
                        <div class="suggestion-card">
                            {suggestion}
                        </div>
                    """, unsafe_allow_html=True)
                
                # Career Path Recommender
                st.markdown("---")
                st.markdown("## Career Path Recommender")
                
                # Initialize recommender
                recommender = CareerPathRecommender()
                
                # Get current role from resume
                current_node = recommender._parse_resume_for_current_state(st.session_state.resume_text)
                
                # Get possible target roles from the graph
                all_roles = set()
                for role, neighbors in recommender.career_graph.items():
                    all_roles.add(role)
                    all_roles.update(neighbors.keys())
                
                # Remove the current role (if detected)
                target_roles = sorted([r for r in all_roles if r != current_node.role])
                
                if target_roles:
                    goal_role = st.selectbox(
                        "Select your target career role:",
                        options=target_roles,
                        index=len(target_roles)-1 if len(target_roles) > 0 else 0
                    )
                    
                    if st.button("Find Career Path", key="career_path"):
                        with st.spinner("Finding optimal career path..."):
                            path, skill_gaps = recommender.find_career_path(st.session_state.resume_text, goal_role)
                            
                            st.markdown(f"""
                                <div class="feedback-card">
                                    <h3>Recommended Career Path from {current_node.role} to {goal_role}</h3>
                                    <div class="path-visualization">
                            """, unsafe_allow_html=True)
                            
                            # Display path as visual timeline
                            for i, role in enumerate(path):
                                st.markdown(f"""
                                    <div class="path-step">
                                        <div class="path-node">{i+1}</div>
                                        <div class="path-role">{role}</div>
                                    </div>
                                """, unsafe_allow_html=True)
                                if i < len(path)-1:
                                    st.markdown('<div class="path-arrow">→</div>', unsafe_allow_html=True)
                            
                            st.markdown("""
                                    </div>
                                </div>
                            """, unsafe_allow_html=True)
                            
                            # Display skill gaps
                            if skill_gaps:
                                st.markdown("""
                                    <div class="feedback-card">
                                        <h3>Skill Development Requirements</h3>
                                """, unsafe_allow_html=True)
                                
                                for gap in skill_gaps:
                                    st.markdown(f"""
                                        <div class="skill-gap-card">
                                            <strong>From {gap['from']} to {gap['to']} (≈{gap['years_required']} years)</strong>
                                            <ul>
                                                {"".join([f"<li>{skill}</li>" for skill in gap['skills_needed']])}
                                            </ul>
                                        </div>
                                    """, unsafe_allow_html=True)
                                
                                st.markdown("</div>", unsafe_allow_html=True)
                            else:
                                st.info("No significant skill gaps detected for this path.")
                else:
                    st.info("Could not detect your current role or find suitable career paths.")
                
                # Download Report
                st.markdown("---")
                report_name = "resume_feedback_report.txt"
                with open(report_name, "w", encoding="utf-8") as f:
                    f.write("Resume Feedback Report\n\n")
                    if isinstance(st.session_state.grammar_section, str):
                        f.write("Grammar & Writing:\n" + st.session_state.grammar_section + "\n\n")
                    else:
                        f.write("Grammar & Writing:\n")
                        for issue in st.session_state.grammar_section:
                            f.write(f"- {issue['issue']} → \"{issue['example']}\"\n")
                        f.write("\n")
                    f.write("Structure & Sections:\n" + st.session_state.section_text + "\n\n")
                    f.write("Keyword Analysis:\n" + st.session_state.keyword_text + "\n\n")
                    f.write(f"Overall Score: {st.session_state.overall_score}/100\n")
                
                with open(report_name, "rb") as f:
                    st.download_button(
                        label="Download Full Report",
                        data=f,
                        file_name=report_name,
                        mime="text/plain",
                        use_container_width=True
                    )
        else:
            st.warning("No readable text found in the uploaded file.")

if __name__ == "__main__":
    main()